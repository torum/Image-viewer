Description
===========
- libwebp.pas    : Pascal headers to Google's library "libwebp.dll" (requires "libwebp.dll")
                   https://developers.google.com/speed/webp/docs/api
                   https://developers.google.com/speed/webp/download
- fpreadwebp.pas : implements TFPReaderWEBP (descendant of TFPCustomImageReader, requires "libwebp.pas")
                   implements TFPWriterWEBP (descendant of TFPCustomImageWriter, requires "libwebp.pas")
- webpimage.pas  : implements TWEBPImage (descendant of TFPImageBitmap, requires "fpreadwebp.pas")

- Win32.DLL      : pre-compiled 32-bit library "libwebp.dll" (requires Microsoft Visual C++ 2010 Redistributable (VC++ 10.0))
                                               "libwebp_static.dll" (does not require MSVC run-time libraries)
- Win64.DLL      : pre-compiled 64-bit library "libwebp.dll" (requires Microsoft Visual C++ 2010 Redistributable (VC++ 10.0))
                                               "libwebp_static.dll" (does not require MSVC run-time libraries)
- VC             : readme.txt (instructions for compilation dynamic library from "libwebp" source codes)


Changelog
=========
Apr 2022	Initial release (version 1.2.2)
Jan 2025	Updated to version 1.5.0 (since version 1.3.2 "libsharpyuv.dll" is also required)
