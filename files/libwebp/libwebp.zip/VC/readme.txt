Compiling using Microsoft Visual C++ 2010 Express:
--------------------------------------------------
1. Download source code (https://developers.google.com/speed/webp/download)
2.1. Replace "winres.h" by "winresrc.h" in *.rc files (fatal error RC1015: cannot open include file 'winres.h')
2.2. Replace "/MANIFEST:EMBED" by "/MANIFEST" in Makefile.vc (fatal error LNK1117: syntax error in option 'MANIFEST:EMBED')
3.a Run "Visual Studio Command Prompt (2010)" from Start menu (for x86)
3.b Run "Windows SDK 7.1 Command Prompt" from Start menu (for x64) (setenv /Release; "vsvars32.bat x64" changes target?)
4. change path to folder where sources are placed (cd D:\TEMP\...\libwebp-1.2.4)
5. Run in command window:
     nmake /f Makefile.vc CFG=release-dynamic RTLIBCFG=static OBJDIR=output (no need of MSVC run-time libraries)
     nmake /f Makefile.vc CFG=release-dynamic RTLIBCFG=dynamic OBJDIR=output
    (nmake /f Makefile.vc ... clean)